package fgk.zad1.main;

import fgk.zad1.Lights.Source;
import fgk.zad1.antyaliasing.AdaptiveSampler;
import fgk.zad1.basics.GraphicsObject;
import fgk.zad1.basics.Ray;
import fgk.zad1.basics.Vector2;
import fgk.zad1.basics.Vector3;
import fgk.zad1.material.Material;
import fgk.zad1.utilitis.Lightintencity;

import java.awt.*;
import java.util.List;

public class Tracer {
    public static final int maxReccuresion = 5;


    /**Ray tracing brute Force
     *
     * @param x
     * @param y
     */
    public void traceBruteForce(int x, int y,List<Source> sources) throws Exception {
        //Poczatkowy kolor

        Driver.image.buffer.setRGB(x,Driver.world.viewPlane.heigth - y -1, calculateLight(x,y,sources).toIntneger());


    }

    public void adaptiveTrace(int x, int y) {
//
        Driver.image.buffer.setRGB(x,Driver.world.viewPlane.heigth - y -1, Driver.sampler.sample(x,y).toIntneger());
    }
    public Lightintencity calculateLight(int x, int y,List<Source> sources) throws Exception {
        Lightintencity color = new Lightintencity(0f, 0f, 0f);
        /** Antyaliasing dzielimy nasz pixel na 8 wiersz i 8 kolumn
         *
         */
        for (int row = 0; row < Driver.sampler.samples; row++) {
            for (int col = 0; col < Driver.sampler.samples; col++) {
                Vector2 vector2 = Driver.sampler.sampleNormal(row,col, x, y);
                Ray ray = Driver.camera.createRay(vector2);
                double min = Double.MAX_VALUE;

                GraphicsObject graphicsObject =    ray.checkFirstIntersectObject();

                if(graphicsObject!=null) {


                    Vector3 intersetion = graphicsObject.checkSectionReturnVector(ray);

                    if (intersetion != null) {
                        for (Source source : sources
                        ) {

                            Vector3 lightDir = source.getSourcePoint().vecSub(intersetion).scalMulti(-1);
                            lightDir.normalize();


                            Ray shadowRay = new Ray(intersetion, lightDir);
                            GraphicsObject firstBumpedObject = shadowRay.checkFirstIntersectObject();
                            if (firstBumpedObject != null) {
                                if (firstBumpedObject.equals(graphicsObject)) {
                                    Material material = graphicsObject.getMaterial();
                                    Vector3 normal = graphicsObject.getNormal(intersetion);
                                    normal.normalize();
                                    Vector3 reflect = lightDir.reflect(normal);
                                    float diff = normal.scalProd(reflect);
                                    if (diff < 0) diff = 0;
                                    float spec = (float) Math.pow(lightDir.scalProd(reflect), source.shiness);
                                    float distance = source.getSourcePoint().vecSub(intersetion).lengthOfVector();
                                    float attenuation = (float) (source.shiness / (10 * distance * distance + distance * 10 ));
                                    Vector3 result = material.getAmbientKa().scalMulti(attenuation).vecAdd(
                                            material.getDiffuseKd().scalMulti(diff)).vecAdd(
                                            material.getSpecularKs().scalMulti(
                                                    spec * attenuation));
                                      color.add(checkMaterial(graphicsObject, ray,result, intersetion));


                                    color.add(new Lightintencity(result.getX() * graphicsObject.getColor().getR(),
                                            result.getY() * graphicsObject.getColor().getG(),
                                            result.getZ() * graphicsObject.getColor().getB()));

                                } else {
                                    Material material = graphicsObject.getMaterial();
                                    Vector3 normal = graphicsObject.getNormal(intersetion);
                                    Vector3 reflect = lightDir.reflect(normal);
                                    float diff = normal.scalProd(lightDir);
                                    if (diff < 0) diff = 0;
                                    float spec = (float) Math.pow(intersetion.scalProd(reflect), source.shiness);
                                    float distance = source.getSourcePoint().vecSub(intersetion).lengthOfVector();
                                    float attenuation = (float) (source.shiness / (10 * distance * distance + distance * 10 + 100));
                                    Vector3 result = material.getAmbientKa().scalMulti(attenuation).vecAdd(
                                            material.getDiffuseKd().scalMulti(diff));

                                      color.add(checkMaterial(graphicsObject, ray,result, intersetion));

                                }
                            } else {
                                Material material = graphicsObject.getMaterial();
                                Vector3 normal = graphicsObject.getNormal(intersetion);
                                Vector3 reflect = lightDir.reflect(normal);
                                float diff = normal.scalProd(lightDir);
                                if (diff < 0) diff = 0;
                                float spec = (float) Math.pow(intersetion.scalProd(reflect), source.shiness);
                                float distance = source.getSourcePoint().vecSub(intersetion).lengthOfVector();
                                float attenuation = (float) (source.shiness / (10 * distance * distance + distance * 10 + 100));
                                Vector3 result = material.getAmbientKa().scalMulti(attenuation).vecAdd(
                                        material.getDiffuseKd().scalMulti(diff)).vecAdd(
                                        material.getSpecularKs().scalMulti(
                                                spec * attenuation));

                                 color.add(checkMaterial(graphicsObject, ray,result, intersetion));
                            }


                        }
                    }
                }




            }
        }
        color.divideByK(Driver.sampler.samples*Driver.sampler.samples);
        return  color;
    }
    public Lightintencity checkMaterial(GraphicsObject graphicsObject, Ray ray, Vector3 result, Vector3 intersection)
    {
        if(graphicsObject.getMaterial().mirror)
        {
            Vector3 normal = graphicsObject.getNormal(intersection);
            Vector3 reflected = ray.getDirection().reflect(normal);
            Ray reflectedRay = new Ray(intersection, reflected);
            GraphicsObject graphicsObject1 = reflectedRay.checkFirstIntersectObject();
            Vector3 section =  graphicsObject.checkSectionReturnVector(reflectedRay);
            if(graphicsObject1!=null)
            {
                if(graphicsObject1.getMaterial().mirror)
                {
                    int i =0;
                    return mirrorRecurresion(i, reflectedRay,graphicsObject1 , result ,section);

                }
                else if(graphicsObject1.getMaterial().transparent)
                {
                    int i =0;
                    return transparentRecuression(i, reflectedRay,graphicsObject1 , result,section );
                }
                else
                {

                    return new Lightintencity(result.getX()*graphicsObject1.getColor().getR(),
                            result.getY()*graphicsObject1.getColor().getG(),
                            result.getZ()*graphicsObject1.getColor().getB());
                }

            }
            else
            {
                return new Lightintencity(result.getX()*graphicsObject.getColor().r,
                        result.getY()*graphicsObject.getColor().g,
                        result.getZ()*graphicsObject.getColor().b);
            }




        }
        else if(graphicsObject.getMaterial().transparent)
        {
            return new Lightintencity(result.getX()*graphicsObject.getColor().getR(),
                    result.getY()*graphicsObject.getColor().getG(),
                    result.getZ()*graphicsObject.getColor().getB());
        }
        else
        {
                return new Lightintencity(result.getX()*graphicsObject.getColor().getR(),
                    result.getY()*graphicsObject.getColor().getG(),
                    result.getZ()*graphicsObject.getColor().getB());
        }
    }
    public Lightintencity transparentRecuression(int i,Ray ray, GraphicsObject graphicsObject,  Vector3 result,Vector3 intersection)
    {
        if(i == maxReccuresion)
        {


        }
        else
        {

        }
        return null;
    }
    public Lightintencity mirrorRecurresion(int i,Ray ray, GraphicsObject graphicsObject,  Vector3 result,Vector3 intersection)
    {

        if(i < maxReccuresion)
        {
            i++;
            Vector3 normal = graphicsObject.getNormal(intersection);
            Vector3 reflectedDirection = ray.getDirection().reflect(normal);
            Ray reflectedRay = new Ray(intersection,reflectedDirection);
            GraphicsObject graphicsObject1 = reflectedRay.checkFirstIntersectObject();
            Vector3 section = graphicsObject1.checkSectionReturnVector(reflectedRay);
            if(graphicsObject1!=null)
            {
                if(graphicsObject1.getMaterial().mirror)
                {

                    return mirrorRecurresion(i, reflectedRay,graphicsObject1 , result ,section);

                }
                else if(graphicsObject1.getMaterial().transparent)
                {

                    return transparentRecuression(i, reflectedRay,graphicsObject1 , result,section );
                }
                else
                {

                    return new Lightintencity(result.getX()*graphicsObject1.getColor().getR(),
                            result.getY()*graphicsObject1.getColor().getG(),
                            result.getZ()*graphicsObject1.getColor().getB());
                }

            }
            else
            {
                return new Lightintencity(result.getX()*Driver.world.background.getR(),
                        result.getY()*Driver.world.background.getG(),
                        result.getZ()*Driver.world.background.getB());
            }

        }
        else
        {
            return new Lightintencity(result.getX()*graphicsObject.getColor().getR(),
                    result.getY()*graphicsObject.getColor().getG(),
                    result.getZ()*graphicsObject.getColor().getB());
        }
    }
}



