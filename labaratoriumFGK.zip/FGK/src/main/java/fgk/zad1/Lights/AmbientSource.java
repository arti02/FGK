package fgk.zad1.Lights;

import fgk.zad1.basics.Vector3;
import fgk.zad1.utilitis.Lightintencity;

public class AmbientSource extends Source {




    @Override
    public Lightintencity getLightintencity() {
        return null;
    }

    @Override
    public Vector3 getSourcePoint() {
        return null;
    }

    public AmbientSource()
    {
        
    }
}
